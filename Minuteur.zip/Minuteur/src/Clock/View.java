package Clock;

import java.awt.*;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;

public class View extends JPanel 
				  implements Observer{

	/**
	 *
	 */

	private static final long serialVersionUID = 1L;
	private static Model m;
	private static Controller c;


	BorderLayout borderLayout;

	public View() {
        borderLayout=new BorderLayout();
        m = new Model();
		c=new Controller(m);
	}

	public View(Controller control){
        borderLayout=new BorderLayout();
        m=control.getM();
        c=control;
    }

	public View(BorderLayout bl)
	{
        borderLayout=bl;
		m=new Model();
		c=new Controller(m);
	}



	public static Controller getC() {
		return c;
	}
	public static Model getM(){ return m; }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		
	}

}
