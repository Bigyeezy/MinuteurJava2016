package Clock;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class Controller implements ActionListener {

    private Model m;
    private ArrayList<ViewButton> vb;
    private ArrayList<ViewOnly> vo;

    public Controller(Model model) {
        m = model;
        vb = new ArrayList<ViewButton>();
        vo = new ArrayList<ViewOnly>();
    }

    public ArrayList<ViewButton> getvb() {
        return vb;
    }

    public void setvb(ArrayList<ViewButton> vbut) {
        vb = vbut;
    }

    public ArrayList<ViewOnly> getvo() {
        return vo;
    }

    public void setvo(ArrayList<ViewOnly> vonly) {
        vo = vonly;
    }

    public Model getM() {
        return m;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String s;
        Object src = e.getSource();
        for (ViewButton v : vb) {
            s = v.getName();
            switch (s) {
                case "Heures":
                    if (v.getButton1() == src) {
                        m.increaseheure();
                    }
                    if (v.getButton2() == src) {
                        m.decreaseheure();
                    }
                    break;
                case "Minutes":
                    if (v.getButton1() == src) {
                        m.increaseminute();
                    }
                    if (v.getButton2() == src) {
                        m.decreaseminute();
                    }
                    break;
                case "Secondes":
                    if (v.getButton1() == src) {
                        m.increasesconde();
                    }
                    if (v.getButton2() == src) {
                        m.decreaseseconde();
                    }
                    break;
            }
            v.uptodate();
        }
        System.out.println(getM().getHeure() + " " + getM().getMinute() + " " + getM().getSeconde());

    }
}
