package Clock;

import java.awt.*;
import java.util.ArrayList;

/**
 * Created by Flo on 29/10/2016.
 */
public class Main {

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.

        Clock c = new Clock();

        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                c.getViewB().createAndShowGUI();
                c.getViewO().createAndShowGUIVO();
            }
        }
        );
    }
}
