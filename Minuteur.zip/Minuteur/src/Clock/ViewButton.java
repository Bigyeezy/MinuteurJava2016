package Clock;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JButton;

import java.awt.*;
import java.util.ResourceBundle;
import javax.swing.JFrame;
import javax.swing.JComponent;


public class ViewButton extends View{

	/**
	 *  Cette classe ViewButton va créer 3 fenêtre avecstaticstaticstaticstatic des
     *  boutons "+" et "-" qui vont incrémenter respectivement
     *  les Heures, les Minutes et les Secondes
     *  et des zones de texte qui vont afficher les données
	 */
	private static final long serialVersionUID = 1L;
	private JButton button1, button2;
    private static Label lab = new Label(" ");

	public ViewButton(Controller control){
        super(control);
	}
	
	public ViewButton (Controller c, String s){
        super(c);
		setName(s);
		switch(s)
		{
            /*
             *Dans le switch
             * Creation des 3 fenetre avec une partie texte pour afficher l'heure
             * et la définition des dimension des zones de texte.
             * Apres le switch
             * On crée deux bouton que l'on ajoute a la fenêtre ainsi crée avec
             * la définition des dimention des boutons.
             */
			case "Heures":
				lab.setText(getM().HeuretoString());
				lab.setPreferredSize(new Dimension(200, 80));
				add(lab, BorderLayout.CENTER);
				break;
			case "Minutes":
                lab.setText(getM().MinutetoString());
				lab.setPreferredSize(new Dimension(200, 80));
				add(lab, BorderLayout.CENTER);
				break;
			case "Secondes":
                lab.setText(getM().SecondetoString());
				lab.setPreferredSize(new Dimension(200, 80));
				add(lab, BorderLayout.CENTER);
				break;
		}
		//bouton plus
		button1 = new JButton("+");
		button1.setPreferredSize(new Dimension(200,80));
        button1.addActionListener(getC());
		add(button1, BorderLayout.WEST);
        //bouton moins
		button2 = new JButton("-");
		button2.setPreferredSize(new Dimension(200,80));
        button2.addActionListener(getC());
		add(button2, BorderLayout.EAST);

        //ajout de la vue avec bouton dans le model
		getC().getvb().add(this);
	}

	public void uptodate()
	{
		for(ViewButton v : getC().getvb())
		{
			switch(v.getName())
			{
				case "Heures":
					v.getLab().setText(getM().HeuretoString());
                    System.out.println(v.getLab().getText());
					break;
				case "Minutes":
					v.getLab().setText(getM().MinutetoString());
                    System.out.println(v.getLab().getText());
					break;
				case "Secondes":
					v.getLab().setText(getM().SecondetoString());
                    System.out.println(v.getLab().getText());
					break;
			}
		}

	}


	private static void creatHeure(){
        //Create and set up the window.
        JFrame frameH = new JFrame("Hours");
        frameH.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        JComponent newContentPaneH = new ViewButton(getC(),"Heures");
        newContentPaneH.setOpaque(true); //content panes must be opaque
        frameH.setContentPane(newContentPaneH);

        //Display the window.
        frameH.pack();
        frameH.setVisible(true);
	}

	private static void creatMinute(){
        JFrame frameM = new JFrame("Minutes");
        frameM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        //Create and set up the content pane.
        JComponent newContentPaneM = new ViewButton(getC(),"Minutes");
        newContentPaneM.setOpaque(true); //content panes must be opaque
        frameM.setContentPane(newContentPaneM);

        //Display the window.
        frameM.pack();
        frameM.setVisible(true);
    }

    private static void creatSeconde(){
        JFrame frameS = new JFrame("Secondes");
        frameS.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        JComponent newContentPaneS = new ViewButton(getC(),"Secondes");
        newContentPaneS.setOpaque(true); //content panes must be opaque
        frameS.setContentPane(newContentPaneS);

        //Display the window.
        frameS.pack();
        frameS.setVisible(true);
    }

	public void createAndShowGUI() {
        creatHeure();
        creatMinute();
        creatSeconde();
	    }



    public Label getLab() {
        return lab;
    }

    public void setLab(Label lab) {
        this.lab = lab;
    }
    public JButton getButton1() {
        return button1;
    }

    public JButton getButton2() {
        return button2;
    }

}
